#' Wikipedia Page Image
#'
#' Takes spreadsheet data and edits the image url of the page for every url inside the sheet
#'
#' @param filename it takes the name of the spreadsheet you want to access
#'
#' @param sheet_name name of the sheet to access within the spreadsheet
#'
#' @param edit_place takes the column and row where the returned image is to be edited eg. R2 where R is column and 2 is row no.
#'
#' @param column takes the column name that needs to be queried for finding the image on the page
#'
#' @import googlesheets
#'
#' @import rvest
#'
#' @import jsonlite
#'
#' @return pos_count: Number of positive changes
#'
#' @return neg_count: Number of cases in which no changes are made
#'
#' @return error: Number of error cases
#'
#' @examples
#' \dontrun{
#' getImagesFromAWikipediaUrl("googlesheetname", "sheetname", "A2", "query_column")
#' }
#'
#' @export
#'
#' @author Pankaj Prajapati
#'
getImagesFromAWikipediaUrl <-
function(filename, sheet_name, edit_place, column){

  library(googlesheets)
  library(rvest)
  library(jsonlite)

  postv_count <- 0 #counts the number of positve returns
  neg_count <- 0 #counts the number of pages which do not have images
  error <- 0 #counts the number of pages which give error

  get_image <- function(for_gs_sheet, column) # function for getting the image from wiki page
  {
    a = list() # new list for storing the image urls to be returned
    j =1 # iterater for moving along the list
    k <- nrow(for_gs_sheet)
    for (i in 1:k)
    {
      tempo <- list()
      sc <- for_gs_sheet[[column]][i] # storing the url for searching
      if(!is.na(sc))
      {

        temp <- sc %>%  #temp stores all the image sources on the page
          xml2::read_html() %>%
          html_nodes("img") %>%
          html_attr("src")

        temp1 <- sc %>%  #temp1 stores the image caption
          xml2::read_html() %>%
          html_nodes("img") %>%
          html_attr("alt")

        temp2 <- sc %>%  #temp1 stores the image width
          xml2::read_html() %>%
          html_nodes("img") %>%
          html_attr("width")

        temp3 <- sc %>%  #temp1 stores the image height
          xml2::read_html() %>%
          html_nodes("img") %>%
          html_attr("height")

        temp4 <- sc %>%  #temp4 stores all text in class attribute
          xml2::read_html() %>%
          html_nodes("div") %>%
          html_nodes("div") %>%
          html_text("class")

        temp5 <- sc %>%  #temp5 stores all the classes in div node
          xml2::read_html() %>%
          html_nodes("div") %>%
          html_nodes("div") %>%
          html_attr("class")
        tryCatch(
          {
            for(l in 1:length(temp)){ #loop for assigning image values
              if(!is.na(temp[l]) & !is.na(temp2[l])){
                if(as.numeric(temp3[l])>100 | as.numeric(temp2[l])>100){ # only takes images with either height or width > 100
                  print(temp2[l])
                  print(temp3[l])
                  print(temp[l])
                  tempo$image_caption <- temp1[l]
                  tempo$image_source <- temp[l]
                  tempo$image_height <- temp3[l]
                  tempo$image_width <- temp2[l]
                  print(tempo)
                  if (tempo$image_caption == ""){ # in case where caption is in form of thumbcation
                    for(t in 1:length(temp5)){
                      if(!is.na(temp5[t])){
                        if(temp5[t] == "thumbcaption"){
                          tempo$image_caption <- temp4[t]
                          break()
                        }
                      }
                    }
                  }
                  postv_count <<- postv_count + 1
                  a[j] <- toJSON(tempo, pretty = TRUE) #assigning values of image to the list in json format

                  break()
                }
              }

            }

          },
          error=function(cond) {
            message("Error message:")
            message(cond)
            # Choose a return value in case of error
            a[j] <- " "
            error <<- error + 1
            return(NA)
          }
        )
        if(is.null(unlist(a[j]))){ #check case for no valid image found
          a[j] = ''
          neg_count <<- neg_count + 1
        }

      }
      else{
        print(sc)
        a[j] <- " "
        neg_count <<- neg_count + 1
      }
      print(a[j])
      j = j + 1
    }
    return(unlist(a)) # returns list a as vector
  }

  for_gs <- gs_title(filename)

  for_gs_sheet <- gs_read(for_gs)

  #insert the rownames vertically in column L
  gs_edit_cells(for_gs, ws = sheet_name, anchor = edit_place, input = get_image(for_gs_sheet, column), byrow = FALSE)
  re <- list(c("Total Positive change count", postv_count), c("Total count for no changes", neg_count), c("Total count for errors", error) )
  return(re)
}

#getImagesFromAWikipediaUrl("test_data", "Sheet1", "D2", "Url")
