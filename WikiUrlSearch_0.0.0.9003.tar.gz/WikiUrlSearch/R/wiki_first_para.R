#' Wikipedia First Paragraph
#'
#' Takes spreadsheet data and edits the first paragraph of the page for every url inside the sheet
#'
#' @param filename it takes the name of the spreadsheet you want to access
#'
#' @param sheet_name name of the sheet to access within the spreadsheet
#'
#' @param edit_place takes the column and row where the returned para is to be edited eg. R2 where R is column and 2 is row no.
#'
#' @param column takes the column name that needs to be queried for finding the paragraphs
#'
#' @import googlesheets
#'
#' @import rvest
#'
#' @export
#'
#' @author Pankaj Prajapati <pankaj@pykih.com>
#'
## ********************
wiki_first_para <-
function(filename, sheet_name, edit_place, column)
  {

  library(googlesheets)
  library(stringr)
  library(rvest)

  first_para <- function(for_gs_sheet, column) # function for getting the first para from wiki page
    {
    a = list() # new list for storing the paragraphs to be returned
    j =1 # iterater for moving along the list
    k <- nrow(for_gs_sheet)
    for (i in 1:k)
      {
      sc <- for_gs_sheet[[column]][i] # storing the url for searching
      if(sc != "N")
        {
        temp <- sc %>%  #temp stores the text of the all paragraphs of the page
          xml2::read_html() %>%
          html_nodes("p") %>% # here p signifies header for paragraph on the html page
          html_text()

        for(l in temp){ # loop for getting the first para out of all the paragraphs in the text
          if (l == "\n" | l == "\n\n" | l == "\n\n\n"){
            next
          }
          else{
            a[j] <- l
            break
          }
        }
      }
      else{
        a[j] <- "error"
      }
      print(a[j])
      j = j + 1
    }
    return(unlist(a)) # returns list a as vector
    }

  #gs_auth(new_user = TRUE)

  for_gs <- gs_title(filename)

  for_gs_sheet <- gs_read(for_gs)

  #insert the rownames vertically in column L
  gs_edit_cells(for_gs, ws = sheet_name, anchor = edit_place, input = first_para(for_gs_sheet, column), byrow = FALSE)

}
