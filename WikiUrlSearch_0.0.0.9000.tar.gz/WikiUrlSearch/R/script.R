#' Wikipedia Url search
#'
#' Edits the wikipedia url of the page name in the spreadsheet
#'
#' @docType package
#' @name WikiUrlSearch
#' @author Pankaj Prajapati

"_PACKAGE"


