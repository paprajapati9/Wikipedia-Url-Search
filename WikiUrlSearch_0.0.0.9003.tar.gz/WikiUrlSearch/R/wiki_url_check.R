#' Check Wikipedia URL
#'
#' Takes spreadsheet data and edits the wikipedia url of speaker's page given it exists
#'
#' @param filename it takes the name of the spreadsheet you want to access
#'
#' @param sheet_name name of the sheet to access within the spreadsheet
#'
#' @param check_place takes the cells from where url is to be checked  eg. R2 where R is column and 2 is row no.
#'
#' @param column takes the column name that needs to be queried for checking the page validity
#'
#' @import googlesheets
#'
#' @import WikipediR
#'
#' @import rvest
#'
#' @export
#'
#' @author Pankaj Prajapati
#'
wiki_url_check <-
function(filename, sheet_name, check_place, column){
  library(googlesheets)
  library(WikipediR)
  url_check <- function(for_gs_sheet, column, check_place){
    a = list()
    j =1
    k <- nrow(for_gs_sheet)
    for (i in 1:k)
    {
      d <- page_info("en","wikipedia", page = for_gs_sheet[[column]][i])
      if(check_place[i] != " "){ #if page has valid page id
        temp <- d$query$pages[[1]]$fullurl %>%
          xml2::read_html() %>%
          html_nodes("h1")

        check <- grepl(for_gs_sheet[[column]][i], temp, fixed = TRUE)

        if (check == TRUE){
          a[j] <- d$query$pages[[1]]$fullurl #saves the url of the searched page in a list
          print(a)
          postv_count <<- postv_count + 1
        }
      }
      j = j + 1
    }
    return(unlist(a))
  }

  #gs_auth(new_user = TRUE)

  for_gs <- gs_title(filename)

  for_gs_sheet <- gs_read(for_gs)

  #insert the rownames vertically in column L
  gs_edit_cells(for_gs, ws = sheet_name, anchor = edit_place, input = url_search(for_gs_sheet, column), byrow = FALSE)
  re <- list(c("Total Positive change count", postv_count), c("Total count for no changes", neg_count) )
  return(re)
}
