#' Search Wikipedia URL
#'
#' Takes spreadsheet data and edits the wikipedia url of speaker's page given it exists
#'
#' @param filename it takes the name of the spreadsheet you want to access
#'
#' @param sheet_name name of the sheet to access within the spreadsheet
#'
#' @param edit_place takes the column and row where the returned url is to be edited eg. R2 where R is column and 2 is row no.
#'
#' @param column takes the column name that needs to be queried for wikipedia url search
#'
#' @import googlesheets
#'
#' @import WikipediR
#'
#' @export
#'
#' @author Pankaj Prajapati
#'
wiki_url_search <-
function(filename, sheet_name, edit_place, column){

    library(googlesheets)
    library(WikipediR)

    postv_count = 0 #counts the number of positve url returns
    neg_count = 0 #counts the number of pages which do not exist

    url_search <- function(for_gs_sheet, column){
      a = list()
      j =1
      k <- nrow(for_gs_sheet)
      for (i in 1:k)
        {
        d <- page_info("en","wikipedia", page = for_gs_sheet[[column]][i])
        if(d$query$pages[[1]][[1]] == 0)#checks for valid page id
          {
          print("This page does not exist")
          a[j] <- " "
          j = j + 1
          neg_count <<- neg_count + 1
          next
          }
        else{ #if page has valid page id
          temp <- d$query$pages[[1]]$fullurl %>%
            xml2::read_html() %>%
            html_nodes("h1")

          check <- grepl(for_gs_sheet[[column]][i], temp, fixed = TRUE)

          if (check == TRUE){
            a[j] <- d$query$pages[[1]]$fullurl #saves the url of the searched page in a list
            print(a)
            postv_count <<- postv_count + 1
          }
        }
        j = j + 1
      }
      return(unlist(a))
    }

    #gs_auth(new_user = TRUE)

    for_gs <- gs_title(filename)

    for_gs_sheet <- gs_read(for_gs)

    #insert the rownames vertically in column L
    gs_edit_cells(for_gs, ws = sheet_name, anchor = edit_place, input = url_search(for_gs_sheet, column), byrow = FALSE)
    re <- list(c("Total Positive change count", postv_count), c("Total count for no changes", neg_count) )
    return(re)
}

#wiki_url_search("speakers2", "speakers", "P2", "speaker_name")
