#' Wikipedia Structured Contents
#'
#' Takes spreadsheet data and edits the structured content of the page for every url inside the sheet
#'
#' @param filename it takes the name of the spreadsheet you want to access
#'
#' @param sheet_name name of the sheet to access within the spreadsheet
#'
#' @param edit_place takes the starting column and row where the returned table is to be edited eg. R2 where R is column and 2 is row no.
#'
#' @param column takes the column name that needs to be queried for finding the table. It must contain only Urls
#'
#' @import googlesheets
#'
#' @import rvest
#'
#' @import jsonlite
#'
#' @return pos_count: Number of positive changes
#'
#' @return neg_count: Number of cases in which no changes are made
#'
#' @return error: Number of error cases
#'
#' @examples
#' \dontrun{
#' getStructuredContentFromAWikipediaUrl("googlesheetname", "sheetname", "A2", "query_column")
#' }
#'
#' @export
#'
#' @author Pankaj Prajapati
#'
getStructuredContentFromAWikipediaUrl <-
function(filename, sheet_name, edit_place, column){

  library(googlesheets)
  library(rvest)
  library(jsonlite)

  postv_count = 0 #counts the number of positve returns
  neg_count = 0 #counts the number of pages which do not have structured content
  error = 0 #counts the number of pages which give error

    setTableData <- function(for_gs_sheet, column) # function for getting the structured content from wiki page
    {
      a = list() # new list for storing the tables to be returned
      j =1 # iterater for moving along the list
      k <- nrow(for_gs_sheet)
      for (i in 1:k)
      {
        sc <- for_gs_sheet[[column]][i] # storing the url for searching
        if(!is.na(sc))
        {
          tryCatch(
            {
              temp <- sc %>%  #temp stores the first table node
                xml2::read_html() %>%
                html_node("table") %>%
                html_table(fill = TRUE)
              temp1 <- sc %>%  #temp1 stores the class attribute
                xml2::read_html() %>%
                html_node("table") %>%
                html_attr("class")
              print(temp1)
              if(temp1 == "nowraplinks hlist navbox-inner"){ # checking class of the table
                neg_count <<- neg_count + 1
                a[j] <- ''
              }
              else{
                a[j] <-toJSON(temp, pretty = TRUE)
                postv_count <<- postv_count + 1
              }

            },
            error=function(cond) {
              message("Error message:")
              message(cond)
              # Choose a return value in case of error
              a[j] <- " "
              error <<- error + 1
              return(NA)
            }
          )
        }
        else{
          a[j] <- " "
          neg_count <<- neg_count + 1
        }
        print(a[j])
        j = j + 1
      }
      return(unlist(a)) # returns list a as vector
    }

    for_gs <- gs_title(filename)

    for_gs_sheet <- gs_read(for_gs)

    #insert the rownames vertically in column L
    gs_edit_cells(for_gs, ws = sheet_name, anchor = edit_place, input = setTableData(for_gs_sheet, column), byrow = FALSE)
    re <- list(c("Total Positive change count", postv_count), c("Total count for no changes", neg_count), c("Total count for errors", error) )
    return(re)
}

#getStructuredContentFromAWikipediaUrl("test_data", "Sheet1", "C2", "Url")

