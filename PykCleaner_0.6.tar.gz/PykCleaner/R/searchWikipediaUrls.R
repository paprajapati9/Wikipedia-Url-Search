#' Search Wikipedia URL
#'
#' Takes spreadsheet data and edits the wikipedia url of a page given it exists
#'
#' @param filename it takes the name of the spreadsheet you want to access
#'
#' @param sheet_name name of the sheet to access within the spreadsheet
#'
#' @param edit_place takes the starting place column and row where the returned url is to be edited eg. R2 where R is column and 2 is row no.
#'
#' @param column takes the column name that needs to be queried for wikipedia url search
#'
#' @import googlesheets
#'
#' @import WikipediR
#'
#' @import stringr
#'
#' @import rvest
#'
#' @return pos_count: Number of positive changes
#'
#' @return neg_count: Number of cases in which page does not exist
#'
#' @return error: Number of error cases
#'
#' @export
#'
#' @examples
#' \dontrun{
#' searchWikipediaUrls("googlesheetname", "sheetname", "A2", "query_column")
#' }
#'
#' @author Pankaj Prajapati
#'
searchWikipediaUrls <-
function(filename, sheet_name, edit_place, column){

    library(googlesheets)
    library(WikipediR)
    library(stringr)
    library(rvest)
    gs_auth(new_user = TRUE) # get authorisation to use google drive

    postv_count = 0 #counts the number of positve url returns
    neg_count = 0 #counts the number of pages which do not exist
    error = 0 #counts the number of pages which give error

    ## Function for cases of disambigouos pages
    disambiguospage <- function(sc, strc){
      temppages <- sc %>%  #temppages stores all the pages linked to the disambiguos page
        xml2::read_html() %>%
        html_nodes("li") %>%
        html_nodes("a") %>%
        html_attr("title")

      t <- str_split(strc, " ") # spliting the queary name for matching purposes

      t <- unlist(t)

      for(m in temppages){ # printing pages linked with the disambiguos page
        if(grepl(t, m, fixed = TRUE)){
          print(m)
        }
      }

      name <- readline(prompt="Enter name: ")
      if (name == '0'){
        return(NA)
      }
      p <- page_info("en","wikipedia", page = name)
      return(p)

    }#function ends

    url_search <- function(for_gs_sheet, column){
      a <- list() #list for storing urls that are later to be retured
      j <- 1 #iterator the list
      k <- nrow(for_gs_sheet)
      for (i in 1:k) # iterating over the all the query names
      {
        name <- str_to_title(for_gs_sheet[[column]][i])
        d <- page_info("en","wikipedia", page = name)

        if(d$query$pages[[1]][[1]] == 0)#checks for valid page id
        {
          print("This page does not exist")
          a[j] <- " "
          j = j + 1
          neg_count <<- neg_count + 1
          next
        }
        else{ #if page has valid page id
          temp1 <- d$query$pages[[1]]$fullurl %>%  #temp stores the text of the all paragraphs of the page
            xml2::read_html() %>%
            html_nodes("p") %>% # here p signifies header for paragraph on the html page
            html_text()

          for(l in temp1){ # loop for getting the first para out of all the paragraphs in the text
            if (l == "\n" | l == "\n\n" | l == "\n\n\n"){
              next
            }
            else{
              paratext <- l
              break
            }
          }
          if(grepl("may refer to", l, fixed = TRUE)){
            print("Disambigous Page\n")
            d <- disambiguospage(d$query$pages[[1]]$fullurl, name) #contains page info of the selected page of all the disambiguos pages
            if(is.na(d)){
              a[j] <- " "
              j <- j + 1
              error <<- error + 1 #incrementing the error count
              next
            }
            if(d$query$pages[[1]][[1]] == 0)#checks for valid page id
            {
              print("This page does not exist")
              a[j] <- " "
              j = j + 1
              neg_count <<- neg_count + 1
              next
            }
          }

          temp <- d$query$pages[[1]]$fullurl %>%
            xml2::read_html() %>%
            html_nodes("h1")

          check <- grepl(name, temp, fixed = TRUE)# checking if the title of the page matches the the query name


          if (check == TRUE){
            a[j] <- d$query$pages[[1]]$fullurl #saves the url of the searched page in a list
            print(a)
            postv_count <<- postv_count + 1
          }
          else{
            a[j] <- " "
            neg_count <<- neg_count + 1
          }
        }
        j = j + 1
      }
      return(unlist(a))
    }


    for_gs <- gs_title(filename)

    for_gs_sheet <- gs_read(for_gs)

    #insert the rownames vertically in column L
    gs_edit_cells(for_gs, ws = sheet_name, anchor = edit_place, input = url_search(for_gs_sheet, column), byrow = FALSE)
    re <- list(c("Total Positive change count", postv_count), c("Total count for no changes", neg_count), c("Total count for errors", error) )
    return(re)
}

#searchWikipediaUrls("test_data", "Sheet1", "B2", "Name")
