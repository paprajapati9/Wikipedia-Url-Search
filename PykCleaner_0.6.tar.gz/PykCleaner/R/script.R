#' PykCleaner
#'
#' This Package contains functions related to parsing information from wikipedia pages
#'
#' @docType package
#' @name PykCleaner
#' @author Pankaj Prajapati <pankaj@pykih.com>

"_PACKAGE"
