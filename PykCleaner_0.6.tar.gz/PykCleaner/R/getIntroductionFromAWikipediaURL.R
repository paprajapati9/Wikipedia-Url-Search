#' Wikipedia Introduction Paragraph
#'
#' Takes spreadsheet data and edits the Introduction of the page for every url inside the sheet
#'
#' @param filename it takes the name of the spreadsheet you want to access
#'
#' @param sheet_name name of the sheet to access within the spreadsheet
#'
#' @param edit_place takes the starting column and row where the returned introduction is to be edited eg. R2 where R is column and 2 is row no.
#'
#' @param column takes the column name that needs to be queried for finding the paragraphs. It must contain only Urls
#'
#' @import googlesheets
#'
#' @import rvest
#'
#' @import jsonlite
#'
#' @return pos_count: Number of positive changes
#'
#' @return neg_count: Number of cases in which no changes are made
#'
#' @examples
#' \dontrun{
#' getIntroductionFromAWikipediaUrl("googlesheetname", "sheetname", "A2", "query_column")
#' }
#'
#' @export
#'
#' @author Pankaj Prajapati
#'
getIntroductionFromAWikipediaUrl <-
function(filename, sheet_name, edit_place, column)
  {

    library(googlesheets)
    library(rvest)
    library(jsonlite)

    postv_count <- 0 #counts the number of positve returns
    neg_count <- 0 #counts the number of pages which do not have images

    first_para <- function(for_gs_sheet, column) # function for getting the first para from wiki page
    {
      a = list() # new list for storing the paragraphs to be returned
      j =1 # iterater for moving along the list
      k <- nrow(for_gs_sheet)
      for (i in 1:k)
      {
        sc <- for_gs_sheet[[column]][i] # storing the url for searching
        if(!is.na(sc)) # checking if the sc is a valid url
        {
          temp <- sc %>%  #temp stores the text of the all paragraphs of the page
            xml2::read_html() %>%
            html_nodes("p") %>% # here p signifies header for paragraph on the html page
            html_text()

          for(l in temp){ # loop for getting the first para out of all the paragraphs in the text
            if (l == "\n" | l == "\n\n"){ # in case the header returns a null value
              next
            }
            if(l == "\n\n\n" | l == "\n\n\n\n"){
              next
            }
            if (l == "\n\n\n\n\n"){
              next
            }
            a[j] <- toJSON(l, pretty = TRUE) #asssigning the json file to list
            postv_count <<- postv_count + 1
            break
          }
        }
        else{
          a[j] <- " " # assigning null value in case no url is found
          neg_count <<- neg_count + 1
        }
        print(a[j])
        j = j + 1
      }
      return(unlist(a)) # returns list a as vector
    }

    #gs_auth(new_user = TRUE)

    for_gs <- gs_title(filename)

    for_gs_sheet <- gs_read(for_gs)

    #insert the rownames vertically in column L
    gs_edit_cells(for_gs, ws = sheet_name, anchor = edit_place, input = first_para(for_gs_sheet, column), byrow = FALSE)
    re <- list(c("Total Positive change count", postv_count), c("Total count for no changes", neg_count))
    return(re)
}

#getIntroductionFromAWikipediaUrl("test_data", "Sheet1", "E2", "Url")
