#' Wikipedia Page Introduction Table
#'
#' Takes spreadsheet data and edits the text for introduction table of the page for every url inside the sheet
#'
#' @param filename it takes the name of the spreadsheet you want to access
#'
#' @param sheet_name name of the sheet to access within the spreadsheet
#'
#' @param edit_place takes the column and row where the returned table is to be edited eg. R2 where R is column and 2 is row no.
#'
#' @param column takes the column name that needs to be queried for finding the table of the page
#'
#' @import googlesheets
#'
#' @import rvest
#'
#' @export
#'
#' @author Pankaj Prajapati <pankaj@pykih.com>
#'
wiki_get_table <-
function(filename, sheet_name, edit_place, column){

  get_table <- function(for_gs_sheet, column) # function for getting the first para from wiki page
  {
    a = list() # new list for storing the paragraphs to be returned
    j =1 # iterater for moving along the list
    k <- nrow(for_gs_sheet)
    for (i in 1:k)
    {
      sc <- for_gs_sheet[[column]][i] # storing the url for searching
      if(sc != "N")
      {

        temp <- sc %>%  #temp stores the first table node
          xml2::read_html() %>%
          html_node("table") %>%
          html_text()
        print(temp)
        tryCatch(
          {
            a[j] <- temp

          },
          error=function(cond) {
            message("Here's the original error message:")
            message(cond)
            # Choose a return value in case of error
            a[j] <- "No table"
            return(NA)
          }
        )

      }
      else{
        a[j] <- "error"
      }
      print(a[j])
      j = j + 1
    }
    return(unlist(a)) # returns list a as vector
  }

  for_gs <- gs_title(filename)

  for_gs_sheet <- gs_read(for_gs)

  #insert the rownames vertically in column L
  gs_edit_cells(for_gs, ws = sheet_name, anchor = edit_place, input = get_table(for_gs_sheet, column), byrow = FALSE)

}

#wiki_get_table("pykcleaner_test_data", "speakers", "R2", "RL")
